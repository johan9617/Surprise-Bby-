EVA BIRTHDAY SURPRISE — FREE WEBSITE

FILES
- index.html: the complete website.

HOW TO PERSONALIZE
1. Open index.html in a text editor (on iPhone, you can use a code editor app; on a computer use Notepad or VS Code).
2. Find "Johan" in the letter and change it if you want.
3. To add photos, copy your pictures into this folder, for example photo1.jpg, photo2.jpg, photo3.jpg.
4. In index.html, find:
   <div class="photo">Your photo 1 🌸</div>
   Replace it with:
   <div class="photo"><img src="photo1.jpg" alt="Memory 1"></div>
   Repeat for photo2.jpg and photo3.jpg.
5. Save the file. Keep the photo files and index.html together in the same folder.

PUBLISH FREE WITH GITHUB PAGES
1. Sign in or create a free account at https://github.com
2. Create a new public repository named eva-birthday (or any name).
3. Upload index.html and your photo files (if you added any) to the repository's main/root folder.
4. Open the repository's Settings → Pages.
5. Under "Build and deployment", choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait a minute or two. GitHub will show a website address like:
   https://YOUR-USERNAME.github.io/eva-birthday/
8. Open that link to test it, then send it to Eva.

NOTES
- The site itself is free and does not need a paid subscription.
- GitHub Pages is free for public repositories.
- This starter version has no external music so it loads quickly and works on phones.
- Only upload photos you have permission to share. A public GitHub Pages link can be viewed by anyone who has it.

NEW INTERACTIVE SURPRISE
- A button shoots an arrow into a heart.
- The heart reveals a tree.
- Tap the tree to make it bloom with heart shapes and little love birds.

PHOTO FILES INCLUDED
- eva-photo-1.jpeg
- eva-photo-2.jpeg
- eva-photo-3.jpeg
All three photos are already connected to the gallery in index.html. Upload these files alongside index.html when publishing.
